// Pet Shop Billing System
const UPI_ID = 'klathish08@oksbi';
const SHOP_NAME = 'AJ Pets World';

class PetShopBilling {
    constructor() {
        this.pets = this.loadData('petShopPets');
        this.items = this.loadData('petShopItems');
        this.sales = this.loadData('petShopSales');
        this.deletedSales = this.loadData('petShopDeletedSales');
        this.cart = [];
        this.currentEditId = null;
        this.currentItemEditId = null;
        this.lastDeletedSale = null;
        this.init();
    }

    init() {
        this.renderPets();
        this.renderItems();
        this.renderSales();
        this.setupEventListeners();
        this.updateItemSelect();
    }

    // Data Management
    loadData(key) {
        const stored = localStorage.getItem(key);
        return stored ? JSON.parse(stored) : [];
    }

    saveData(key, data) {
        localStorage.setItem(key, JSON.stringify(data));
    }

    saveDeletedSales() {
        this.saveData('petShopDeletedSales', this.deletedSales);
    }

    // Navigation
    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.switchPage(e.target.dataset.page);
            });
        });

        // Pets
        document.getElementById('addPetBtn')?.addEventListener('click', () => {
            this.openPetModal();
        });
        document.getElementById('closeModal')?.addEventListener('click', () => {
            this.closePetModal();
        });
        document.getElementById('cancelBtn')?.addEventListener('click', () => {
            this.closePetModal();
        });
        document.getElementById('petForm')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.savePet();
        });
        document.getElementById('searchInput')?.addEventListener('input', (e) => {
            this.filterPets(e.target.value);
        });

        // Items
        document.getElementById('addItemBtn')?.addEventListener('click', () => {
            this.openItemModal();
        });
        document.getElementById('closeItemModal')?.addEventListener('click', () => {
            this.closeItemModal();
        });
        document.getElementById('cancelItemBtn')?.addEventListener('click', () => {
            this.closeItemModal();
        });
        document.getElementById('itemForm')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.saveItem();
        });
        document.getElementById('itemSearchInput')?.addEventListener('input', (e) => {
            this.filterItems(e.target.value);
        });

        // Billing
        document.getElementById('addToCartBtn')?.addEventListener('click', () => {
            this.addToCart();
        });
        document.getElementById('increaseQty')?.addEventListener('click', () => {
            const qtyInput = document.getElementById('itemQuantity');
            qtyInput.value = parseInt(qtyInput.value) + 1;
        });
        document.getElementById('decreaseQty')?.addEventListener('click', () => {
            const qtyInput = document.getElementById('itemQuantity');
            const current = parseInt(qtyInput.value) || 1;
            if (current > 1) {
                qtyInput.value = current - 1;
            }
        });
        document.getElementById('generateInvoiceBtn')?.addEventListener('click', () => {
            this.generateInvoice();
        });
        document.getElementById('clearCartBtn')?.addEventListener('click', () => {
            this.clearCart();
        });
        document.querySelectorAll('input[name="paymentMethod"]').forEach(radio => {
            radio.addEventListener('change', (e) => {
                this.updatePaymentMethod(e.target.value);
            });
        });

        // Invoice
        document.getElementById('closeInvoiceModal')?.addEventListener('click', () => {
            this.closeInvoiceModal();
        });
        document.getElementById('closeInvoiceBtn')?.addEventListener('click', () => {
            this.closeInvoiceModal();
        });
        document.getElementById('printInvoiceBtn')?.addEventListener('click', () => {
            this.printInvoice();
        });

        // Sales History
        document.getElementById('salesSearchInput')?.addEventListener('input', (e) => {
            this.filterSales(e.target.value);
        });
        document.getElementById('customerFilter')?.addEventListener('change', (e) => {
            this.filterByCustomer(e.target.value);
        });
        document.getElementById('filterDateBtn')?.addEventListener('click', () => {
            this.filterSalesByDate();
        });
        document.getElementById('filterAllBtn')?.addEventListener('click', () => {
            this.applyQuickFilter('all');
        });
        document.getElementById('filterTodayBtn')?.addEventListener('click', () => {
            this.applyQuickFilter('today');
        });
        document.getElementById('filterWeekBtn')?.addEventListener('click', () => {
            this.applyQuickFilter('week');
        });
        document.getElementById('filterMonthBtn')?.addEventListener('click', () => {
            this.applyQuickFilter('month');
        });
        document.getElementById('undoDeleteBtn')?.addEventListener('click', () => {
            this.undoDelete();
        });
        document.getElementById('exportSalesBtn')?.addEventListener('click', () => {
            this.exportSalesHistory();
        });
        document.getElementById('exportAllBtn')?.addEventListener('click', () => {
            this.exportAllData();
        });
        document.getElementById('importDataBtn')?.addEventListener('click', () => {
            document.getElementById('importFileInput')?.click();
        });
        document.getElementById('importFileInput')?.addEventListener('change', (e) => {
            this.importData(e.target.files[0]);
        });

        // Delete modals
        document.getElementById('confirmDeleteBtn')?.addEventListener('click', () => {
            this.confirmDelete();
        });
        document.getElementById('cancelDeleteBtn')?.addEventListener('click', () => {
            this.closeDeleteModal();
        });

        // Modal outside clicks
        document.getElementById('petModal')?.addEventListener('click', (e) => {
            if (e.target.id === 'petModal') this.closePetModal();
        });
        document.getElementById('itemModal')?.addEventListener('click', (e) => {
            if (e.target.id === 'itemModal') this.closeItemModal();
        });
        document.getElementById('invoiceModal')?.addEventListener('click', (e) => {
            if (e.target.id === 'invoiceModal') this.closeInvoiceModal();
        });
        document.getElementById('deleteModal')?.addEventListener('click', (e) => {
            if (e.target.id === 'deleteModal') this.closeDeleteModal();
        });
    }

    switchPage(page) {
        document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
        document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
        
        document.getElementById(`${page}Page`).classList.add('active');
        document.querySelector(`[data-page="${page}"]`).classList.add('active');

        if (page === 'billing') {
            this.updateItemSelect();
            this.updateCartDisplay();
            // Generate QR code on page load (even if cart is empty)
            this.updateUPIQR(this.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0));
        }
    }

    // Pets Management
    openPetModal(pet = null) {
        const modal = document.getElementById('petModal');
        const form = document.getElementById('petForm');
        const title = document.getElementById('modalTitle');

        if (pet) {
            title.textContent = 'Edit Pet';
            this.currentEditId = pet.id;
            document.getElementById('petId').value = pet.id;
            document.getElementById('petName').value = pet.name;
            document.getElementById('petType').value = pet.type;
            document.getElementById('petBreed').value = pet.breed || '';
            document.getElementById('petAge').value = pet.age || '';
            document.getElementById('petPrice').value = pet.price;
            document.getElementById('petDescription').value = pet.description || '';
        } else {
            title.textContent = 'Add New Pet';
            this.currentEditId = null;
            form.reset();
        }
        modal.classList.add('show');
    }

    closePetModal() {
        document.getElementById('petModal').classList.remove('show');
        document.getElementById('petForm').reset();
        this.currentEditId = null;
    }

    savePet() {
        const form = document.getElementById('petForm');
        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }

        const petData = {
            id: this.currentEditId || Date.now().toString(),
            name: document.getElementById('petName').value.trim(),
            type: document.getElementById('petType').value,
            breed: document.getElementById('petBreed').value.trim(),
            age: document.getElementById('petAge').value ? parseInt(document.getElementById('petAge').value) : null,
            price: parseFloat(document.getElementById('petPrice').value),
            description: document.getElementById('petDescription').value.trim()
        };

        if (this.currentEditId) {
            const index = this.pets.findIndex(p => p.id === this.currentEditId);
            if (index !== -1) this.pets[index] = petData;
        } else {
            this.pets.push(petData);
        }

        this.saveData('petShopPets', this.pets);
        this.renderPets();
        this.closePetModal();
        this.updateItemSelect();
    }

    deletePet(id) {
        const pet = this.pets.find(p => p.id === id);
        if (pet) {
            document.getElementById('deletePetName').textContent = pet.name;
            document.getElementById('deleteModal').classList.add('show');
            this.pendingDeleteId = id;
            this.pendingDeleteType = 'pet';
        }
    }

    editPet(id) {
        const pet = this.pets.find(p => p.id === id);
        if (pet) this.openPetModal(pet);
    }

    renderPets() {
        const grid = document.getElementById('petsGrid');
        const emptyState = document.getElementById('emptyState');

        if (this.pets.length === 0) {
            grid.innerHTML = '';
            emptyState.classList.add('show');
            return;
        }

        emptyState.classList.remove('show');
        grid.innerHTML = this.pets.map(pet => this.createPetCard(pet)).join('');

        this.pets.forEach(pet => {
            document.getElementById(`edit-${pet.id}`)?.addEventListener('click', () => {
                this.editPet(pet.id);
            });
            document.getElementById(`delete-${pet.id}`)?.addEventListener('click', () => {
                this.deletePet(pet.id);
            });
        });
    }

    createPetCard(pet) {
        return `
            <div class="pet-card" data-breed="${pet.breed || ''}" data-description="${pet.description || ''}">
                <div class="pet-header">
                    <div>
                        <div class="pet-name">${this.escapeHtml(pet.name)}</div>
                        <span class="pet-type">${this.escapeHtml(pet.type)}</span>
                    </div>
                </div>
                <div class="pet-price">₹${pet.price.toFixed(2)}</div>
                <div class="pet-details">
                    ${pet.breed ? `<p><strong>Breed:</strong> ${this.escapeHtml(pet.breed)}</p>` : ''}
                    ${pet.age !== null ? `<p><strong>Age:</strong> ${pet.age} ${pet.age === 1 ? 'year' : 'years'}</p>` : ''}
                    ${pet.description ? `<p class="pet-description">${this.escapeHtml(pet.description)}</p>` : ''}
                </div>
                <div class="pet-actions">
                    <button class="btn btn-edit" id="edit-${pet.id}">Edit</button>
                    <button class="btn btn-delete" id="delete-${pet.id}">Delete</button>
                </div>
            </div>
        `;
    }

    filterPets(term) {
        const searchTerm = term.toLowerCase().trim();
        const cards = document.querySelectorAll('.pet-card');
        let visibleCount = 0;

        cards.forEach(card => {
            const name = card.querySelector('.pet-name').textContent.toLowerCase();
            const type = card.querySelector('.pet-type').textContent.toLowerCase();
            const breed = card.dataset.breed ? card.dataset.breed.toLowerCase() : '';
            const description = card.dataset.description ? card.dataset.description.toLowerCase() : '';

            if (searchTerm === '' || name.includes(searchTerm) || type.includes(searchTerm) || 
                breed.includes(searchTerm) || description.includes(searchTerm)) {
                card.classList.remove('hidden');
                visibleCount++;
            } else {
                card.classList.add('hidden');
            }
        });

        const emptyState = document.getElementById('emptyState');
        if (visibleCount === 0 && this.pets.length > 0) {
            emptyState.textContent = 'No pets match your search.';
            emptyState.classList.add('show');
        } else if (this.pets.length === 0) {
            emptyState.textContent = 'No pets available. Add your first pet!';
            emptyState.classList.add('show');
        } else {
            emptyState.classList.remove('show');
        }
    }

    // Items Management
    openItemModal(item = null) {
        const modal = document.getElementById('itemModal');
        const form = document.getElementById('itemForm');
        const title = document.getElementById('itemModalTitle');

        if (item) {
            title.textContent = 'Edit Item';
            this.currentItemEditId = item.id;
            document.getElementById('itemId').value = item.id;
            document.getElementById('itemName').value = item.name;
            document.getElementById('itemCategory').value = item.category;
            document.getElementById('itemPrice').value = item.price;
            document.getElementById('itemStock').value = item.stock || 0;
            document.getElementById('itemDescription').value = item.description || '';
        } else {
            title.textContent = 'Add New Item';
            this.currentItemEditId = null;
            form.reset();
        }
        modal.classList.add('show');
    }

    closeItemModal() {
        document.getElementById('itemModal').classList.remove('show');
        document.getElementById('itemForm').reset();
        this.currentItemEditId = null;
    }

    saveItem() {
        const form = document.getElementById('itemForm');
        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }

        const itemData = {
            id: this.currentItemEditId || Date.now().toString(),
            name: document.getElementById('itemName').value.trim(),
            category: document.getElementById('itemCategory').value,
            price: parseFloat(document.getElementById('itemPrice').value),
            stock: parseInt(document.getElementById('itemStock').value) || 0,
            description: document.getElementById('itemDescription').value.trim()
        };

        if (this.currentItemEditId) {
            const index = this.items.findIndex(i => i.id === this.currentItemEditId);
            if (index !== -1) this.items[index] = itemData;
        } else {
            this.items.push(itemData);
        }

        this.saveData('petShopItems', this.items);
        this.renderItems();
        this.closeItemModal();
        this.updateItemSelect();
    }

    deleteItem(id) {
        const item = this.items.find(i => i.id === id);
        if (item) {
            document.getElementById('deletePetName').textContent = item.name;
            document.getElementById('deleteModal').classList.add('show');
            this.pendingDeleteId = id;
            this.pendingDeleteType = 'item';
        }
    }

    editItem(id) {
        const item = this.items.find(i => i.id === id);
        if (item) this.openItemModal(item);
    }

    renderItems() {
        const grid = document.getElementById('itemsGrid');
        const emptyState = document.getElementById('itemsEmptyState');

        if (this.items.length === 0) {
            grid.innerHTML = '';
            emptyState.classList.add('show');
            return;
        }

        emptyState.classList.remove('show');
        grid.innerHTML = this.items.map(item => this.createItemCard(item)).join('');

        this.items.forEach(item => {
            document.getElementById(`edit-item-${item.id}`)?.addEventListener('click', () => {
                this.editItem(item.id);
            });
            document.getElementById(`delete-item-${item.id}`)?.addEventListener('click', () => {
                this.deleteItem(item.id);
            });
        });
    }

    createItemCard(item) {
        const stockClass = item.stock < 10 ? 'low' : '';
        return `
            <div class="item-card">
                <div class="item-header">
                    <div>
                        <div class="item-name">${this.escapeHtml(item.name)}</div>
                        <span class="item-category">${this.escapeHtml(item.category)}</span>
                    </div>
                </div>
                <div class="item-price">₹${item.price.toFixed(2)}</div>
                <div class="item-stock ${stockClass}">
                    Stock: ${item.stock}
                </div>
                ${item.description ? `<p class="pet-description">${this.escapeHtml(item.description)}</p>` : ''}
                <div class="pet-actions">
                    <button class="btn btn-edit" id="edit-item-${item.id}">Edit</button>
                    <button class="btn btn-delete" id="delete-item-${item.id}">Delete</button>
                </div>
            </div>
        `;
    }

    filterItems(term) {
        const searchTerm = term.toLowerCase().trim();
        const cards = document.querySelectorAll('.item-card');
        let visibleCount = 0;

        cards.forEach(card => {
            const name = card.querySelector('.item-name').textContent.toLowerCase();
            const category = card.querySelector('.item-category').textContent.toLowerCase();
            const description = card.querySelector('.pet-description')?.textContent.toLowerCase() || '';

            if (searchTerm === '' || name.includes(searchTerm) || category.includes(searchTerm) || 
                description.includes(searchTerm)) {
                card.classList.remove('hidden');
                visibleCount++;
            } else {
                card.classList.add('hidden');
            }
        });

        const emptyState = document.getElementById('itemsEmptyState');
        if (visibleCount === 0 && this.items.length > 0) {
            emptyState.textContent = 'No items match your search.';
            emptyState.classList.add('show');
        } else if (this.items.length === 0) {
            emptyState.textContent = 'No items available. Add your first item!';
            emptyState.classList.add('show');
        } else {
            emptyState.classList.remove('show');
        }
    }

    // Billing & Cart
    updateItemSelect() {
        const select = document.getElementById('itemSelect');
        if (!select) return;

        select.innerHTML = '<option value="">Select Item or Pet</option>';
        
        // Add pets
        this.pets.forEach(pet => {
            const option = document.createElement('option');
            option.value = `pet-${pet.id}`;
            option.textContent = `🐾 ${pet.name} (Pet) - ₹${pet.price.toFixed(2)}`;
            select.appendChild(option);
        });

        // Add items
        this.items.forEach(item => {
            const option = document.createElement('option');
            option.value = `item-${item.id}`;
            option.textContent = `📦 ${item.name} (${item.category}) - ₹${item.price.toFixed(2)}`;
            select.appendChild(option);
        });
    }

    addToCart() {
        const select = document.getElementById('itemSelect');
        const quantity = parseInt(document.getElementById('itemQuantity').value) || 1;

        if (!select.value) {
            alert('Please select an item or pet');
            return;
        }

        const [type, id] = select.value.split('-');
        let item;

        if (type === 'pet') {
            item = this.pets.find(p => p.id === id);
            if (item) {
                this.cart.push({
                    id: `pet-${item.id}`,
                    name: item.name,
                    type: 'Pet',
                    price: item.price,
                    quantity: quantity
                });
            }
        } else if (type === 'item') {
            item = this.items.find(i => i.id === id);
            if (item) {
                if (item.stock < quantity) {
                    alert(`Only ${item.stock} items available in stock`);
                    return;
                }
                this.cart.push({
                    id: `item-${item.id}`,
                    name: item.name,
                    type: item.category,
                    price: item.price,
                    quantity: quantity
                });
            }
        }

        this.updateCartDisplay();
        select.value = '';
        document.getElementById('itemQuantity').value = 1;
    }

    removeFromCart(index) {
        this.cart.splice(index, 1);
        this.updateCartDisplay();
    }

    clearCart() {
        if (this.cart.length === 0) return;
        if (confirm('Clear all items from cart?')) {
            this.cart = [];
            this.updateCartDisplay();
            document.getElementById('customerName').value = '';
            document.getElementById('customerPhone').value = '';
            document.getElementById('customerAddress').value = '';
        }
    }

    updateCartDisplay() {
        const cartBody = document.getElementById('cartBody');
        const cartTotal = document.getElementById('cartTotal');
        
        if (!cartBody) return;

        if (this.cart.length === 0) {
            cartBody.innerHTML = '<tr><td colspan="5" style="text-align: center; color: #999; padding: 2rem;">🛒 Cart is empty. Add items to get started!</td></tr>';
            cartTotal.textContent = '₹0.00';
            const cartCount = document.getElementById('cartItemCount');
            if (cartCount) cartCount.textContent = `(0)`;
            // Generate QR code without amount (customer can enter manually)
            this.updateUPIQR(0);
            return;
        }

        let total = 0;
        cartBody.innerHTML = this.cart.map((item, index) => {
            const itemTotal = item.price * item.quantity;
            total += itemTotal;
            return `
                <tr class="cart-row">
                    <td>
                        <div class="cart-item-name">
                            <strong>${this.escapeHtml(item.name)}</strong>
                            <span class="cart-item-type">${this.escapeHtml(item.type)}</span>
                        </div>
                    </td>
                    <td>${item.quantity}</td>
                    <td>₹${item.price.toFixed(2)}</td>
                    <td><strong>₹${itemTotal.toFixed(2)}</strong></td>
                    <td>
                        <button class="remove-item" onclick="petShop.removeFromCart(${index})" title="Remove">
                            <span>✕</span>
                        </button>
                    </td>
                </tr>
            `;
        }).join('');

        cartTotal.textContent = `₹${total.toFixed(2)}`;
        document.getElementById('cartItemCount').textContent = `(${this.cart.length})`;
        this.updateUPIQR(total);
    }

    updateUPIQR(amount) {
        const qrContainer = document.getElementById('upiQrCode');
        const qrOverlay = document.getElementById('qrOverlay');
        const amountDisplay = document.getElementById('upiAmount');
        const qrPlaceholder = document.getElementById('qrPlaceholder');
        
        if (!qrContainer) return;

        amountDisplay.textContent = `₹${amount.toFixed(2)}`;

        // Build UPI payment string
        // When amount is 0, generate QR without amount (customer can enter manually)
        // When amount > 0, include the amount in QR code
        let upiString;
        if (amount > 0) {
            // QR code with specific amount
            upiString = `upi://pay?pa=${UPI_ID}&pn=${encodeURIComponent('Lathish Kumar')}&am=${amount.toFixed(2)}&cu=INR`;
        } else {
            // QR code without amount (customer enters amount manually)
            upiString = `upi://pay?pa=${UPI_ID}&pn=${encodeURIComponent('Lathish Kumar')}&cu=INR`;
        }
        
        // Hide placeholder
        if (qrPlaceholder) qrPlaceholder.style.display = 'none';
        
        // Remove any existing canvas
        const existingCanvas = qrContainer.querySelector('canvas');
        if (existingCanvas) existingCanvas.remove();
        
        // Create canvas for QR code
        const canvas = document.createElement('canvas');
        QRCode.toCanvas(canvas, upiString, {
            width: 250,
            margin: 2,
            color: {
                dark: '#000000',
                light: '#FFFFFF'
            },
            errorCorrectionLevel: 'M'
        }, (error) => {
            if (error) {
                console.error('QR Code generation error:', error);
                if (qrPlaceholder) {
                    qrPlaceholder.textContent = 'QR Code generation failed. Please refresh the page.';
                    qrPlaceholder.style.display = 'block';
                }
                if (qrOverlay) qrOverlay.classList.add('hidden');
            } else {
                qrContainer.appendChild(canvas);
                // Add Google Pay style logo overlay
                if (qrOverlay) {
                    qrOverlay.classList.remove('hidden');
                    qrOverlay.innerHTML = `
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect x="2" y="2" width="10" height="10" fill="#4285F4" rx="2"/>
                            <rect x="12" y="2" width="10" height="10" fill="#34A853" rx="2"/>
                            <rect x="2" y="12" width="10" height="10" fill="#EA4335" rx="2"/>
                            <rect x="12" y="12" width="10" height="10" fill="#FBBC04" rx="2"/>
                        </svg>
                    `;
                }
            }
        });
    }

    updatePaymentMethod(method) {
        const upiSection = document.getElementById('upiSection');
        if (method === 'upi') {
            upiSection.style.display = 'block';
        } else {
            upiSection.style.display = 'none';
        }
    }

    generateInvoice() {
        const customerName = document.getElementById('customerName').value.trim();
        
        if (!customerName) {
            alert('Please enter customer name');
            return;
        }

        if (this.cart.length === 0) {
            alert('Cart is empty. Add items to generate invoice.');
            return;
        }

        const paymentMethod = document.querySelector('input[name="paymentMethod"]:checked').value;
        const invoiceNumber = 'INV-' + Date.now();
        const invoiceDate = new Date().toLocaleDateString('en-IN');
        const invoiceTime = new Date().toLocaleTimeString('en-IN');

        let total = 0;
        const items = this.cart.map(item => {
            const itemTotal = item.price * item.quantity;
            total += itemTotal;
            return {
                name: item.name,
                type: item.type,
                quantity: item.quantity,
                price: item.price,
                total: itemTotal
            };
        });

        const invoice = {
            id: invoiceNumber,
            date: invoiceDate,
            time: invoiceTime,
            customer: {
                name: customerName,
                phone: document.getElementById('customerPhone').value.trim(),
                address: document.getElementById('customerAddress').value.trim()
            },
            items: items,
            total: total,
            paymentMethod: paymentMethod
        };

        this.sales.push(invoice);
        this.saveData('petShopSales', this.sales);

        // Update stock for items
        this.cart.forEach(cartItem => {
            if (cartItem.id.startsWith('item-')) {
                const itemId = cartItem.id.replace('item-', '');
                const item = this.items.find(i => i.id === itemId);
                if (item) {
                    item.stock -= cartItem.quantity;
                }
            }
        });
        this.saveData('petShopItems', this.items);

        this.displayInvoice(invoice);
        this.clearCart();
        this.renderItems();
        this.renderSales();
    }

    displayInvoice(invoice) {
        const invoiceContent = document.getElementById('invoiceContent');
        invoiceContent.innerHTML = `
            <div class="invoice">
                <div class="invoice-header">
                    <h2>${SHOP_NAME}</h2>
                    <p>Invoice</p>
                    <p><strong>Invoice #:</strong> ${invoice.id}</p>
                    <p><strong>Date:</strong> ${invoice.date} ${invoice.time}</p>
                </div>
                
                <div class="invoice-details">
                    <div>
                        <h3>Bill To:</h3>
                        <p><strong>${this.escapeHtml(invoice.customer.name)}</strong></p>
                        ${invoice.customer.phone ? `<p>Phone: ${this.escapeHtml(invoice.customer.phone)}</p>` : ''}
                        ${invoice.customer.address ? `<p>${this.escapeHtml(invoice.customer.address)}</p>` : ''}
                    </div>
                    <div>
                        <h3>Payment Method:</h3>
                        <p><strong>${invoice.paymentMethod.toUpperCase()}</strong></p>
                    </div>
                </div>

                <table class="invoice-table">
                    <thead>
                        <tr>
                            <th>Item</th>
                            <th>Type</th>
                            <th>Qty</th>
                            <th>Price</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${invoice.items.map(item => `
                            <tr>
                                <td>${this.escapeHtml(item.name)}</td>
                                <td>${this.escapeHtml(item.type)}</td>
                                <td>${item.quantity}</td>
                                <td>₹${item.price.toFixed(2)}</td>
                                <td>₹${item.total.toFixed(2)}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>

                <div class="invoice-total">
                    <p>Total Amount: <strong>₹${invoice.total.toFixed(2)}</strong></p>
                </div>
            </div>
        `;

        document.getElementById('invoiceModal').classList.add('show');
    }

    closeInvoiceModal() {
        document.getElementById('invoiceModal').classList.remove('show');
    }

    printInvoice() {
        const invoiceContent = document.getElementById('invoiceContent').innerHTML;
        const printWindow = window.open('', '_blank');
        printWindow.document.write(`
            <html>
                <head>
                    <title>Invoice</title>
                    <style>
                        body { font-family: Arial, sans-serif; padding: 20px; }
                        .invoice { max-width: 800px; margin: 0 auto; }
                        .invoice-header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #000; padding-bottom: 10px; }
                        .invoice-details { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin: 20px 0; }
                        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
                        th { background-color: #f5f5f5; }
                        .invoice-total { text-align: right; margin-top: 20px; font-size: 1.2em; font-weight: bold; }
                    </style>
                </head>
                <body>${invoiceContent}</body>
            </html>
        `);
        printWindow.document.close();
        printWindow.print();
    }

    // Sales History
    renderSales() {
        this.updateSalesStats();
        this.updateCustomerFilter();
        const salesList = document.getElementById('salesList');
        const emptyState = document.getElementById('salesEmptyState');

        if (this.sales.length === 0) {
            salesList.innerHTML = '';
            emptyState.classList.add('show');
            return;
        }

        emptyState.classList.remove('show');
        salesList.innerHTML = this.sales.slice().reverse().map(sale => this.createSaleCard(sale)).join('');

        this.sales.forEach(sale => {
            document.getElementById(`view-invoice-${sale.id}`)?.addEventListener('click', () => {
                this.displayInvoice(sale);
            });
            document.getElementById(`delete-sale-${sale.id}`)?.addEventListener('click', () => {
                this.deleteSale(sale.id);
            });
        });
    }

    updateCustomerFilter() {
        // #region agent log
        fetch('http://127.0.0.1:7242/ingest/64a5b3f7-ffc1-4064-9f54-f5197c69c404',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'script.js:850',message:'updateCustomerFilter called',data:{totalSales:this.sales.length},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'A'})}).catch(()=>{});
        // #endregion

        const customerFilter = document.getElementById('customerFilter');
        if (!customerFilter) return;

        // Get unique customers with their phone numbers
        const customerMap = new Map();
        this.sales.forEach(sale => {
            const key = sale.customer.name.toLowerCase().trim();
            if (!customerMap.has(key)) {
                customerMap.set(key, {
                    name: sale.customer.name,
                    phone: sale.customer.phone || '',
                    count: 0
                });
            }
            customerMap.get(key).count++;
        });

        // Sort customers alphabetically
        const sortedCustomers = Array.from(customerMap.values()).sort((a, b) => 
            a.name.localeCompare(b.name)
        );

        // #region agent log
        fetch('http://127.0.0.1:7242/ingest/64a5b3f7-ffc1-4064-9f54-f5197c69c404',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'script.js:870',message:'Unique customers found',data:{uniqueCustomers:sortedCustomers.length},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'A'})}).catch(()=>{});
        // #endregion

        // Save current selection
        const currentValue = customerFilter.value;

        // Populate dropdown
        customerFilter.innerHTML = '<option value="">All Customers</option>';
        sortedCustomers.forEach(customer => {
            const option = document.createElement('option');
            option.value = customer.name.toLowerCase().trim();
            const displayText = customer.phone 
                ? `${customer.name} (${customer.phone}) - ${customer.count} sale(s)`
                : `${customer.name} - ${customer.count} sale(s)`;
            option.textContent = displayText;
            customerFilter.appendChild(option);
        });

        // Restore selection if it still exists
        if (currentValue) {
            customerFilter.value = currentValue;
        }
    }

    filterByCustomer(customerName) {
        // #region agent log
        fetch('http://127.0.0.1:7242/ingest/64a5b3f7-ffc1-4064-9f54-f5197c69c404',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'script.js:890',message:'filterByCustomer called',data:{customerName,totalSales:this.sales.length},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'A'})}).catch(()=>{});
        // #endregion

        if (!customerName) {
            // Show all sales
            this.renderSales();
            return;
        }

        const filtered = this.sales.filter(sale => 
            sale.customer.name.toLowerCase().trim() === customerName
        );

        // #region agent log
        fetch('http://127.0.0.1:7242/ingest/64a5b3f7-ffc1-4064-9f54-f5197c69c404',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'script.js:900',message:'Customer filter completed',data:{customerName,filteredCount:filtered.length},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'A'})}).catch(()=>{});
        // #endregion

        const salesList = document.getElementById('salesList');
        const emptyState = document.getElementById('salesEmptyState');
        
        if (filtered.length === 0) {
            salesList.innerHTML = '<p style="text-align: center; color: #999; padding: 2rem;">No sales found for this customer.</p>';
            emptyState.classList.remove('show');
        } else {
            salesList.innerHTML = filtered.slice().reverse().map(sale => this.createSaleCard(sale)).join('');
            emptyState.classList.remove('show');
            
            // Re-attach event listeners
            filtered.forEach(sale => {
                document.getElementById(`view-invoice-${sale.id}`)?.addEventListener('click', () => {
                    this.displayInvoice(sale);
                });
                document.getElementById(`delete-sale-${sale.id}`)?.addEventListener('click', () => {
                    this.deleteSale(sale.id);
                });
            });
        }
    }

    createSaleCard(sale) {
        return `
            <div class="sale-item" data-sale-id="${sale.id}" 
                 data-customer-name="${this.escapeHtml(sale.customer.name).toLowerCase()}"
                 data-customer-phone="${sale.customer.phone ? this.escapeHtml(sale.customer.phone).toLowerCase() : ''}"
                 data-invoice-id="${sale.id.toLowerCase()}">
                <div class="sale-info">
                    <h4>Invoice #${sale.id}</h4>
                    <p><strong>Customer:</strong> ${this.escapeHtml(sale.customer.name)}</p>
                    ${sale.customer.phone ? `<p><strong>Phone:</strong> ${this.escapeHtml(sale.customer.phone)}</p>` : ''}
                    <p><strong>Date:</strong> ${sale.date} ${sale.time}</p>
                    <p><strong>Items:</strong> ${sale.items.length} item(s)</p>
                    <p><strong>Payment:</strong> ${sale.paymentMethod.toUpperCase()}</p>
                </div>
                <div class="sale-amount">₹${sale.total.toFixed(2)}</div>
                <div class="sale-actions">
                    <button class="btn btn-primary" id="view-invoice-${sale.id}">View Invoice</button>
                    <button class="btn btn-danger btn-icon" id="delete-sale-${sale.id}" title="Delete">
                        <span>🗑️</span>
                    </button>
                </div>
            </div>
        `;
    }

    updateSalesStats() {
        const totalSales = this.sales.reduce((sum, sale) => sum + sale.total, 0);
        const today = new Date().toLocaleDateString('en-IN');
        const todaySales = this.sales
            .filter(sale => sale.date === today)
            .reduce((sum, sale) => sum + sale.total, 0);

        document.getElementById('totalSalesAmount').textContent = `₹${totalSales.toFixed(2)}`;
        document.getElementById('totalInvoices').textContent = this.sales.length;
        document.getElementById('todaySales').textContent = `₹${todaySales.toFixed(2)}`;
    }

    filterSales(term) {
        // #region agent log
        fetch('http://127.0.0.1:7242/ingest/64a5b3f7-ffc1-4064-9f54-f5197c69c404',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'script.js:900',message:'filterSales called',data:{searchTerm:term,totalSales:this.sales.length},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'A'})}).catch(()=>{});
        // #endregion

        const searchTerm = term.toLowerCase().trim();
        const saleItems = document.querySelectorAll('.sale-item');
        let visibleCount = 0;

        saleItems.forEach(item => {
            // Search in multiple fields: invoice ID, customer name, customer phone, and displayed text
            const invoiceId = item.dataset.invoiceId || '';
            const customerName = item.dataset.customerName || '';
            const customerPhone = item.dataset.customerPhone || '';
            const displayText = item.textContent.toLowerCase();

            // #region agent log
            if (visibleCount < 2) { // Log first 2 items for debugging
                fetch('http://127.0.0.1:7242/ingest/64a5b3f7-ffc1-4064-9f54-f5197c69c404',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'script.js:910',message:'Searching sale item',data:{invoiceId,customerName,customerPhone,searchTerm,matches:invoiceId.includes(searchTerm) || customerName.includes(searchTerm) || customerPhone.includes(searchTerm) || displayText.includes(searchTerm)},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'B'})}).catch(()=>{});
            }
            // #endregion

            if (searchTerm === '' || 
                invoiceId.includes(searchTerm) || 
                customerName.includes(searchTerm) || 
                customerPhone.includes(searchTerm) || 
                displayText.includes(searchTerm)) {
                item.classList.remove('hidden');
                visibleCount++;
            } else {
                item.classList.add('hidden');
            }
        });

        // #region agent log
        fetch('http://127.0.0.1:7242/ingest/64a5b3f7-ffc1-4064-9f54-f5197c69c404',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'script.js:930',message:'Filter completed',data:{visibleCount,totalItems:saleItems.length,searchTerm},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'A'})}).catch(()=>{});
        // #endregion

        const emptyState = document.getElementById('salesEmptyState');
        if (visibleCount === 0 && this.sales.length > 0) {
            emptyState.textContent = 'No sales match your search.';
            emptyState.classList.add('show');
        } else if (this.sales.length === 0) {
            emptyState.textContent = 'No sales history available.';
            emptyState.classList.add('show');
        } else {
            emptyState.classList.remove('show');
        }
    }

    applyQuickFilter(filterType) {
        // #region agent log
        fetch('http://127.0.0.1:7242/ingest/64a5b3f7-ffc1-4064-9f54-f5197c69c404',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'script.js:954',message:'applyQuickFilter called',data:{filterType,totalSales:this.sales.length},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'A'})}).catch(()=>{});
        // #endregion

        // Update active button
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        const buttonId = filterType === 'all' ? 'filterAllBtn' : 
                         filterType === 'today' ? 'filterTodayBtn' :
                         filterType === 'week' ? 'filterWeekBtn' : 'filterMonthBtn';
        document.getElementById(buttonId)?.classList.add('active');

        // Clear custom date inputs
        document.getElementById('startDate').value = '';
        document.getElementById('endDate').value = '';

        let start, end;
        const now = new Date();

        if (filterType === 'all') {
            // Show all sales
            this.renderSales();
            return;
        } else if (filterType === 'today') {
            // Today: start and end of today
            start = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0);
            end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);
        } else if (filterType === 'week') {
            // This week: Monday to Sunday
            const dayOfWeek = now.getDay();
            const diff = now.getDate() - dayOfWeek + (dayOfWeek === 0 ? -6 : 1); // Adjust to Monday
            const monday = new Date(now);
            monday.setDate(diff);
            monday.setHours(0, 0, 0, 0);
            start = monday;
            const sunday = new Date(monday);
            sunday.setDate(monday.getDate() + 6);
            sunday.setHours(23, 59, 59, 999);
            end = sunday;
        } else if (filterType === 'month') {
            // This month: first day to last day of current month
            start = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0);
            end = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);
        }

        // #region agent log
        fetch('http://127.0.0.1:7242/ingest/64a5b3f7-ffc1-4064-9f54-f5197c69c404',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'script.js:975',message:'Date range calculated',data:{filterType,start:start.toISOString(),end:end.toISOString()},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'A'})}).catch(()=>{});
        // #endregion

        const filtered = this.sales.filter(sale => {
            // Parse sale.date (DD/MM/YYYY format)
            const dateParts = sale.date.split('/');
            if (dateParts.length !== 3) {
                return false;
            }
            
            // Convert DD/MM/YYYY to Date object
            const day = parseInt(dateParts[0], 10);
            const month = parseInt(dateParts[1], 10) - 1; // Month is 0-indexed
            const year = parseInt(dateParts[2], 10);
            const saleDate = new Date(year, month, day);

            return saleDate >= start && saleDate <= end;
        });

        // #region agent log
        fetch('http://127.0.0.1:7242/ingest/64a5b3f7-ffc1-4064-9f54-f5197c69c404',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'script.js:995',message:'Quick filter completed',data:{filterType,filteredCount:filtered.length,totalSales:this.sales.length},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'A'})}).catch(()=>{});
        // #endregion

        const salesList = document.getElementById('salesList');
        const emptyState = document.getElementById('salesEmptyState');
        
        if (filtered.length === 0) {
            salesList.innerHTML = `<p style="text-align: center; color: #999; padding: 2rem;">No sales found for ${filterType === 'today' ? 'today' : filterType === 'week' ? 'this week' : 'this month'}</p>`;
            emptyState.classList.remove('show');
        } else {
            salesList.innerHTML = filtered.slice().reverse().map(sale => this.createSaleCard(sale)).join('');
            emptyState.classList.remove('show');
            
            // Re-attach event listeners
            filtered.forEach(sale => {
                document.getElementById(`view-invoice-${sale.id}`)?.addEventListener('click', () => {
                    this.displayInvoice(sale);
                });
                document.getElementById(`delete-sale-${sale.id}`)?.addEventListener('click', () => {
                    this.deleteSale(sale.id);
                });
            });
        }
    }

    filterSalesByDate() {
        // #region agent log
        fetch('http://127.0.0.1:7242/ingest/64a5b3f7-ffc1-4064-9f54-f5197c69c404',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'script.js:927',message:'filterSalesByDate called',data:{totalSales:this.sales.length},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'A'})}).catch(()=>{});
        // #endregion

        const startDate = document.getElementById('startDate').value;
        const endDate = document.getElementById('endDate').value;

        // #region agent log
        fetch('http://127.0.0.1:7242/ingest/64a5b3f7-ffc1-4064-9f54-f5197c69c404',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'script.js:933',message:'Date inputs retrieved',data:{startDate,endDate},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'A'})}).catch(()=>{});
        // #endregion

        if (!startDate || !endDate) {
            alert('Please select both start and end dates');
            return;
        }

        // Convert input dates (YYYY-MM-DD) to Date objects at start/end of day
        const start = new Date(startDate + 'T00:00:00');
        const end = new Date(endDate + 'T23:59:59');

        // #region agent log
        fetch('http://127.0.0.1:7242/ingest/64a5b3f7-ffc1-4064-9f54-f5197c69c404',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'script.js:942',message:'Date objects created',data:{start:start.toISOString(),end:end.toISOString()},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'A'})}).catch(()=>{});
        // #endregion

        const filtered = this.sales.filter(sale => {
            // Parse sale.date (DD/MM/YYYY format)
            const dateParts = sale.date.split('/');
            if (dateParts.length !== 3) {
                // #region agent log
                fetch('http://127.0.0.1:7242/ingest/64a5b3f7-ffc1-4064-9f54-f5197c69c404',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'script.js:950',message:'Invalid date format',data:{saleDate:sale.date,saleId:sale.id},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'B'})}).catch(()=>{});
                // #endregion
                return false;
            }
            
            // Convert DD/MM/YYYY to Date object
            const day = parseInt(dateParts[0], 10);
            const month = parseInt(dateParts[1], 10) - 1; // Month is 0-indexed
            const year = parseInt(dateParts[2], 10);
            const saleDate = new Date(year, month, day);

            // #region agent log
            if (this.sales.indexOf(sale) < 3) { // Log first 3 for debugging
                fetch('http://127.0.0.1:7242/ingest/64a5b3f7-ffc1-4064-9f54-f5197c69c404',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'script.js:960',message:'Date comparison',data:{saleDate:sale.date,parsedDate:saleDate.toISOString(),start:start.toISOString(),end:end.toISOString(),inRange:saleDate >= start && saleDate <= end},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'C'})}).catch(()=>{});
            }
            // #endregion

            return saleDate >= start && saleDate <= end;
        });

        // #region agent log
        fetch('http://127.0.0.1:7242/ingest/64a5b3f7-ffc1-4064-9f54-f5197c69c404',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'script.js:968',message:'Filter completed',data:{filteredCount:filtered.length,totalSales:this.sales.length},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'A'})}).catch(()=>{});
        // #endregion

        const salesList = document.getElementById('salesList');
        const emptyState = document.getElementById('salesEmptyState');
        
        if (filtered.length === 0) {
            salesList.innerHTML = '<p style="text-align: center; color: #999; padding: 2rem;">No sales found for selected date range</p>';
            emptyState.classList.remove('show');
        } else {
            salesList.innerHTML = filtered.slice().reverse().map(sale => this.createSaleCard(sale)).join('');
            emptyState.classList.remove('show');
            
            // Re-attach event listeners
            filtered.forEach(sale => {
                document.getElementById(`view-invoice-${sale.id}`)?.addEventListener('click', () => {
                    this.displayInvoice(sale);
                });
                document.getElementById(`delete-sale-${sale.id}`)?.addEventListener('click', () => {
                    this.deleteSale(sale.id);
                });
            });
        }
    }

    deleteSale(saleId) {
        const sale = this.sales.find(s => s.id === saleId);
        if (!sale) return;

        if (confirm(`Are you sure you want to delete Invoice #${saleId}?`)) {
            // Store deleted sale for undo
            this.lastDeletedSale = sale;
            this.deletedSales.push({
                ...sale,
                deletedAt: new Date().toISOString()
            });
            this.saveDeletedSales();

            // Remove from sales
            this.sales = this.sales.filter(s => s.id !== saleId);
            this.saveData('petShopSales', this.sales);

            // Restore stock for items
            sale.items.forEach(invoiceItem => {
                if (invoiceItem.type !== 'Pet') {
                    const item = this.items.find(i => i.name === invoiceItem.name);
                    if (item) {
                        item.stock += invoiceItem.quantity;
                    }
                }
            });
            this.saveData('petShopItems', this.items);

            // Show undo notification
            this.showUndoNotification();

            // Re-render
            this.renderSales();
            this.renderItems();
        }
    }

    undoDelete() {
        if (!this.lastDeletedSale) return;

        // Restore the sale
        this.sales.push(this.lastDeletedSale);
        this.saveData('petShopSales', this.sales);

        // Remove from deleted sales
        this.deletedSales = this.deletedSales.filter(s => s.id !== this.lastDeletedSale.id);
        this.saveDeletedSales();

        // Restore stock deduction
        this.lastDeletedSale.items.forEach(invoiceItem => {
            if (invoiceItem.type !== 'Pet') {
                const item = this.items.find(i => i.name === invoiceItem.name);
                if (item) {
                    item.stock = Math.max(0, item.stock - invoiceItem.quantity);
                }
            }
        });
        this.saveData('petShopItems', this.items);

        // Hide notification
        this.hideUndoNotification();

        // Re-render
        this.renderSales();
        this.renderItems();

        this.lastDeletedSale = null;
    }

    showUndoNotification() {
        const notification = document.getElementById('undoNotification');
        if (notification) {
            notification.style.display = 'flex';
            setTimeout(() => {
                notification.classList.add('show');
            }, 10);
            // Auto-hide after 5 seconds
            setTimeout(() => {
                this.hideUndoNotification();
            }, 5000);
        }
    }

    hideUndoNotification() {
        const notification = document.getElementById('undoNotification');
        if (notification) {
            notification.classList.remove('show');
            setTimeout(() => {
                notification.style.display = 'none';
            }, 300);
        }
    }

    // Delete confirmation
    confirmDelete() {
        if (this.pendingDeleteType === 'pet') {
            this.pets = this.pets.filter(p => p.id !== this.pendingDeleteId);
            this.saveData('petShopPets', this.pets);
            this.renderPets();
            this.updateItemSelect();
        } else if (this.pendingDeleteType === 'item') {
            this.items = this.items.filter(i => i.id !== this.pendingDeleteId);
            this.saveData('petShopItems', this.items);
            this.renderItems();
            this.updateItemSelect();
        }
        this.closeDeleteModal();
    }

    closeDeleteModal() {
        document.getElementById('deleteModal').classList.remove('show');
        this.pendingDeleteId = null;
        this.pendingDeleteType = null;
    }

    // Export/Import Data
    exportSalesHistory() {
        const exportData = {
            exportDate: new Date().toISOString(),
            exportType: 'sales_history',
            sales: this.sales,
            deletedSales: this.deletedSales,
            stats: {
                totalSales: this.sales.reduce((sum, sale) => sum + sale.total, 0),
                totalInvoices: this.sales.length,
                exportDate: new Date().toLocaleDateString('en-IN')
            }
        };

        const dataStr = JSON.stringify(exportData, null, 2);
        const dataBlob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(dataBlob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `sales_history_${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);

        alert(`Sales history exported successfully! File: ${link.download}`);
    }

    exportAllData() {
        const exportData = {
            exportDate: new Date().toISOString(),
            exportType: 'all_data',
            version: '1.0',
            pets: this.pets,
            items: this.items,
            sales: this.sales,
            deletedSales: this.deletedSales,
            stats: {
                totalPets: this.pets.length,
                totalItems: this.items.length,
                totalSales: this.sales.reduce((sum, sale) => sum + sale.total, 0),
                totalInvoices: this.sales.length,
                exportDate: new Date().toLocaleDateString('en-IN')
            }
        };

        const dataStr = JSON.stringify(exportData, null, 2);
        const dataBlob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(dataBlob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `pet_shop_backup_${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);

        alert(`All data exported successfully! File: ${link.download}`);
    }

    importData(file) {
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const importedData = JSON.parse(e.target.result);
                
                if (!importedData.exportType) {
                    alert('Invalid file format. Please select a valid backup file.');
                    return;
                }

                let confirmMessage = '';
                if (importedData.exportType === 'sales_history') {
                    confirmMessage = `Import ${importedData.sales?.length || 0} sales records? This will merge with existing data.`;
                } else if (importedData.exportType === 'all_data') {
                    confirmMessage = `Import all data?\n- ${importedData.pets?.length || 0} Pets\n- ${importedData.items?.length || 0} Items\n- ${importedData.sales?.length || 0} Sales\n\nThis will merge with existing data.`;
                } else {
                    alert('Unknown file type.');
                    return;
                }

                if (confirm(confirmMessage)) {
                    this.processImportedData(importedData);
                    alert('Data imported successfully!');
                }
            } catch (error) {
                console.error('Import error:', error);
                alert('Error importing file. Please check if it\'s a valid JSON file.');
            }
        };
        reader.readAsText(file);
        
        // Reset file input
        document.getElementById('importFileInput').value = '';
    }

    processImportedData(importedData) {
        if (importedData.exportType === 'sales_history') {
            // Merge sales history
            if (importedData.sales && Array.isArray(importedData.sales)) {
                // Avoid duplicates by checking invoice IDs
                const existingIds = new Set(this.sales.map(s => s.id));
                const newSales = importedData.sales.filter(s => !existingIds.has(s.id));
                this.sales = [...this.sales, ...newSales];
                this.saveData('petShopSales', this.sales);
            }

            // Merge deleted sales
            if (importedData.deletedSales && Array.isArray(importedData.deletedSales)) {
                const existingDeletedIds = new Set(this.deletedSales.map(s => s.id));
                const newDeletedSales = importedData.deletedSales.filter(s => !existingDeletedIds.has(s.id));
                this.deletedSales = [...this.deletedSales, ...newDeletedSales];
                this.saveDeletedSales();
            }
        } else if (importedData.exportType === 'all_data') {
            // Merge pets
            if (importedData.pets && Array.isArray(importedData.pets)) {
                const existingPetIds = new Set(this.pets.map(p => p.id));
                const newPets = importedData.pets.filter(p => !existingPetIds.has(p.id));
                this.pets = [...this.pets, ...newPets];
                this.saveData('petShopPets', this.pets);
            }

            // Merge items
            if (importedData.items && Array.isArray(importedData.items)) {
                const existingItemIds = new Set(this.items.map(i => i.id));
                const newItems = importedData.items.filter(i => !existingItemIds.has(i.id));
                this.items = [...this.items, ...newItems];
                this.saveData('petShopItems', this.items);
            }

            // Merge sales
            if (importedData.sales && Array.isArray(importedData.sales)) {
                const existingSaleIds = new Set(this.sales.map(s => s.id));
                const newSales = importedData.sales.filter(s => !existingSaleIds.has(s.id));
                this.sales = [...this.sales, ...newSales];
                this.saveData('petShopSales', this.sales);
            }

            // Merge deleted sales
            if (importedData.deletedSales && Array.isArray(importedData.deletedSales)) {
                const existingDeletedIds = new Set(this.deletedSales.map(s => s.id));
                const newDeletedSales = importedData.deletedSales.filter(s => !existingDeletedIds.has(s.id));
                this.deletedSales = [...this.deletedSales, ...newDeletedSales];
                this.saveDeletedSales();
            }
        }

        // Re-render everything
        this.renderPets();
        this.renderItems();
        this.renderSales();
        this.updateItemSelect();
    }

    // Utility
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Initialize the application
let petShop;
document.addEventListener('DOMContentLoaded', () => {
    petShop = new PetShopBilling();
});
